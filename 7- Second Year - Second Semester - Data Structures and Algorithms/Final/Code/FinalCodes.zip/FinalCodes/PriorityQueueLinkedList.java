package Final_ds;

public class PriorityQueueLinkedList {
	
	private class Node
	{
		String data;
		int priority;
		
		Node nextAddress;
		
		Node(String data, int priority)
		{
			this.data = data;
			this.priority = priority;
		}
		
	}
	
	Node head;
	//Node rear;
	
	void insert(String data, int priority) 
	{
		
		Node newNode = new Node(data, priority);
		
		if (head == null || priority < head.priority) 
		{
            newNode.nextAddress = head;
            head = newNode;
        }
		
		else 
		{
	            // Start with the head node
			Node currentNode = head;

	            // Traverse the list and find the position to insert new node based on the priority
			while (currentNode.nextAddress != null && currentNode.nextAddress.priority <= priority)
			{
	                currentNode = currentNode.nextAddress;
			}

	       // Insert the new node
			newNode.nextAddress = currentNode.nextAddress;
			currentNode.nextAddress = newNode;
		}
			
			
	}
	
	String getMin() 
	{
		
		if (head == null) 
		{
            System.out.println("Priority queue is empty");
        }
		
        return head.data;
    }

	
	void removeMin()
	{
		
		if (head == null)
		{
            System.out.println("Priority queue is empty");
        }
        head = head.nextAddress;
    }
	
	
	
	
	
}
