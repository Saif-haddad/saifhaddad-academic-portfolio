package Final_ds;

public class Dijkstras {

    public static void dijkstra(int[][] graph, int source) throws Exception 
    {
        if (graph.length == 0) 
        {
            throw new Exception("Graph is empty");
        }

        int vertices = graph.length;
        int[] distances = new int[vertices];
        boolean[] visited = new boolean[vertices];
        int[] previous = new int[vertices];

        for (int i = 0; i < vertices; i++)
        {
            distances[i] = Integer.MAX_VALUE; // Initialize all distances to infinity
            visited[i] = false; // Mark all vertices as unvisited
            previous[i] = -1; // Initialize all previous vertices as -1
        }

        distances[source] = 0; // Set the distance of the source vertex to 0

        for (int i = 0; i < vertices - 1; i++) 
        {
            int minVertex = findMinVertex(distances, visited); // Find the vertex with the minimum distance
            visited[minVertex] = true; // Mark the minimum distance vertex as visited

            for (int j = 0; j < vertices; j++) 
            {
                if (graph[minVertex][j] < 0) 
                {
                    throw new Exception("Graph has negative edge");
                }
                if (!visited[j] && graph[minVertex][j] != 0 && distances[minVertex] != Integer.MAX_VALUE &&
                        distances[minVertex] + graph[minVertex][j] < distances[j]) 
                {
                    distances[j] = distances[minVertex] + graph[minVertex][j]; // Update the distance
                    previous[j] = minVertex; // Update the previous vertex
                }
            }
        }

        printDistances(distances, previous); // Print the final shortest path distances
    }

    private static int findMinVertex(int[] distances, boolean[] visited) 
    {
        int minDistance = Integer.MAX_VALUE;
        int minVertex = -1;

        for (int i = 0; i < distances.length; i++) 
        {
            if (!visited[i] && distances[i] < minDistance) 
            {
                minDistance = distances[i];
                minVertex = i;
            }
        }

        return minVertex;
    }

    private static void printDistances(int[] distances, int[] previous) 
    {
        System.out.println("Vertex \tDistance   \tPrevious Vertex");

        for (int i = 0; i < distances.length; i++) 
        {
            String prevVertex = "None";
            if (previous[i] != -1) {
                prevVertex = Integer.toString(previous[i]);
            }
            System.out.println(i + "\t" + distances[i] + "\t\t" + prevVertex);
        }
    }

    public static void main(String[] args) 
    {
        int[][] graph = {
            {0, 24, 5, 10, 0, 0},
            {0, 0, 0, 0, 0, 0},
            {0, 0, 0, 1, 30, 10},
            {0, 0, 0, 0, 0, 8},
            {0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 20, 0}
        };

        try 
        {
            dijkstra(graph, 0);
        } 
        catch (Exception e) 
        {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
