package Final_ds;

public class MainPriorityQueueLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		PriorityQueueLinkedList queue = new PriorityQueueLinkedList();
		//queue.getMin();
		//queue.removeMin();
		queue.insert("saif", 5);
		//System.out.println(queue.getMin());
		queue.insert("salim", 7);
		queue.insert("salim", 9);

		
		System.out.println(queue.getMin());
		
		queue.removeMin();

		System.out.println(queue.getMin());


	}

}
