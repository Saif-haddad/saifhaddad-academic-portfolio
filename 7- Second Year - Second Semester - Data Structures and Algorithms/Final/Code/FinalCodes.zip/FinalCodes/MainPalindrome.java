package Final_ds;

public class MainPalindrome {
	
	static boolean isit_Palindrome(char arr[])
	{
		int len = arr.length;
		
		for(int i = 0; i <= len / 2; i++) 
		{
			int front = arr[i];
			int back = arr[len - i - 1];
			
			// convert front to lowercase if it's uppercase
			if(front >= 65 && front <= 90)
			{
				front += 32;
			}
			
			// convert back to lowercase if it's uppercase
			if(back >= 65 && back <= 90)
			{
				back += 32;
			}
			
			if(front != back)
			{
				return false;
			}
		}
		return true;
	}
	

	public static void main(String[] args) {
		char word[] = {'L', 'e', 'v', 'e', 'l'};
		
		System.out.println(isit_Palindrome(word));
	}
}