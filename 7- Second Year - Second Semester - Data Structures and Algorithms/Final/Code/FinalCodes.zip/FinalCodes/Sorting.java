package Final_ds;
public class Sorting {
    public static void selectionSort(int arr[]){
    	
    	int len = arr.length;

    	// One by one move boundary of unsorted subarray
        for (int i = len-1; i > 0; i--) {
            // Find the maximum element in unsorted array
            int max_idx = i;
            for (int j = i-1; j >= 0; j--)
                if (arr[j] > arr[max_idx])
                    max_idx = j;

            // Swap the found maximum element with the last element of unsorted array
            int temp = arr[max_idx];
            arr[max_idx] = arr[i];
            arr[i] = temp;
        }
    }
    
    public static void mergeSort(int arr[]){
        //write your code here
    	if (arr.length <= 1) {
            return;
        }

        int mid = arr.length / 2;
        int[] left = new int[mid];
        int[] right = new int[arr.length - mid];

        // Split the array into left and right halves
        for (int i = 0; i < mid; i++) {
            left[i] = arr[i];
        }
        for (int i = mid; i < arr.length; i++) {
            right[i - mid] = arr[i];
        }

        // Recursively sort the left and right halves
        mergeSort(left);
        mergeSort(right);

        // Merge the sorted halves
        merge(arr, left, right);
    }
    public static void merge(int[] arr, int[] left, int[] right) {
        int leftLength = left.length;
        int rightLength = right.length;
        int i = 0, j = 0, k = 0;

        while (i < leftLength && j < rightLength) {
            if (left[i] <= right[j]) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }

        while (i < leftLength) {
            arr[k++] = left[i++];
        }

        while (j < rightLength) {
            arr[k++] = right[j++];
        }
    }
    
    public static void generateArray(int arr[],int size,int flag){
        //flag = 1 means sorted
        //flag = 0 means reversely sorted
        if(flag == 1){
          for(int i=0;i<size;i++)
              arr[i]=i;
        }else{
            for(int i=size;i>0;i--)
              arr[size-i]=i;  
        } 
    }
    
    public static void main(String[] args) {
    	
    	
        int arr5000Sorted[]=new int[5000];
        generateArray(arr5000Sorted, 5000, 1);
        int arr5000Unsorted[]=new int[5000];
        generateArray(arr5000Unsorted, 5000, 0);
        
        int arr50000Sorted[]=new int[50000];
        generateArray(arr50000Sorted, 50000, 1);
        int arr50000Unsorted[]=new int[50000];
        generateArray(arr50000Unsorted, 50000, 0);
        
        int arr500000Sorted[]=new int[500000];
        generateArray(arr500000Sorted, 500000, 1);
        int arr500000Unsorted[]=new int[500000];
        generateArray(arr500000Unsorted, 500000, 0);
      
        
        
        
        ////////////////////////////////////////////////
        ////////////    Selection Sort      ////////////
        ////////////////////////////////////////////////
        
        
        System.out.println("******************");
        System.out.println("*****Time to run Selection Sort*****");
        System.out.println("******************");
        //time to sort array 5000 sorted using selection
        long startTime = System.nanoTime();
          selectionSort(arr5000Sorted);        
        long elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 5000 sorted using selection sort in millis: "
                + elapsedTime/1000000.0);
      
        //time to sort array 5000 unsorted using selection
        startTime = System.nanoTime();
          selectionSort(arr5000Unsorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 5000 unsorted using selection sort in millis: "
                + elapsedTime/1000000.0);
        startTime=0;
        elapsedTime=0;
       
        //time to sort array 50000 sorted using selection
        startTime = System.nanoTime();
          selectionSort(arr50000Sorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 50000 sorted using selection sort in millis: "
                + elapsedTime/1000000.0);
        startTime=0;
        elapsedTime=0;
      
        //time to sort array 50000 unsorted using selection
        startTime = System.nanoTime();
          selectionSort(arr50000Unsorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 50000 unsorted using selection sort in millis: "
                + elapsedTime/1000000.0);
        startTime=0;
        elapsedTime=0;
       
        
        //time to sort array 500000 sorted using selection
        startTime = System.nanoTime();
          selectionSort(arr500000Sorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 500000 sorted using selection sort in millis: "
                + elapsedTime/1000000.0);
        startTime=0;
        elapsedTime=0;
      
        //time to sort array 500000 unsorted using selection
        startTime = System.nanoTime();
          selectionSort(arr500000Unsorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 500000 unsorted using selection sort in millis: "
                + elapsedTime/1000000.0);
        startTime=0;
        elapsedTime=0;
       
        
        
        
        ////////////////////////////////////////////////
        ////////////        Merge Sort      ////////////
        ////////////////////////////////////////////////
        
        System.out.println("******************");
        System.out.println("*****Time to run Merge Sort*****");
        System.out.println("******************");
        
        //time to sort array 5000 sorted using merge 
        startTime = System.nanoTime();
          mergeSort(arr5000Sorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 5000 sorted using merge sort in millis: "
                + elapsedTime/1000000.0);
      
        //time to sort array 5000 unsorted using merge
        startTime = System.nanoTime();
          mergeSort(arr5000Unsorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 5000 unsorted using merge sort in millis: "
                + elapsedTime/1000000.0);
       
        //time to sort array 50000 sorted using merge
        startTime = System.nanoTime();
          mergeSort(arr50000Sorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 50000 sorted using merge sort in millis: "
                + elapsedTime/1000000.0);
      
        //time to sort array 50000 unsorted using merge
        startTime = System.nanoTime();
          mergeSort(arr50000Unsorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 50000 unsorted using merge sort in millis: "
                + elapsedTime/1000000.0);
       
        
        //time to sort array 500000 sorted using merge
        startTime = System.nanoTime();
          mergeSort(arr500000Sorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 500000 sorted using merge sort in millis: "
                + elapsedTime/1000000.0);
      
        //time to sort array 500000 unsorted using merge
        startTime = System.nanoTime();
          mergeSort(arr500000Unsorted);        
        elapsedTime = System.nanoTime() - startTime;
     
        System.out.println("Time to sort array 500000 unsorted using merge in millis: "
                + elapsedTime/1000000.0);
       
        
        
    }
}