// Include standard libraries for input/output, process control, interprocess communication (IPC), and shared memory.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <sys/types.h>

// Define the size of the buffer.
#define BUFFER_SIZE 5

// Define a structure for shared buffer data between producer and consumer processes.
typedef struct 
{
    int data[BUFFER_SIZE];
    int write_pos, read_pos;
    int total_consumed, total_produced;
} shared_buffer_Data_Struct;

// Declare a variable to store the number of items to be produced by each producer.
int production_count;

// Function to check if the buffer is full
int isBufferFull(shared_buffer_Data_Struct *shared)
{
    return ((shared->write_pos + 1) % BUFFER_SIZE) == shared->read_pos;
}

// Function to check if the buffer is empty
int isBufferEmpty(shared_buffer_Data_Struct *shared) 
{
    return shared->write_pos == shared->read_pos;
}

// Producer function: produces items and writes them into the shared buffer.
void producer(shared_buffer_Data_Struct* shared, int producer_id) 
{
    int start_value, end_value; 
    
    // Assign different ranges based on the producer ID.
    switch (producer_id) 
    {
        case 1:
            start_value = 1;
            end_value = 3;
            break;
            
        default:
        start_value = 4;
        end_value = 6;
        break;
            
    }
    
    // Produce items up to the production count.
    for (int i = 0; i < production_count; i++) {
        int item = start_value + (i % (end_value - start_value + 1));
        
        // Wait if the buffer is full.
        while (isBufferFull(shared)) {
            ; // Busy-wait (do nothing).

        }
        
        // Write the produced item into the buffer and update write position and produced count.
        shared->data[shared->write_pos] = item;
        shared->write_pos = (shared->write_pos + 1) % BUFFER_SIZE;
        shared->total_produced++;
        
        // Print the production status.
        printf("Producer %d produced: %d. Total items produced: %d\n", producer_id, item, shared->total_produced);
        sleep(2);
    }
}

// Consumer function: consumes items from the shared buffer.
void consumer(shared_buffer_Data_Struct* shared, int consumer_id) 
{
    while(shared->total_consumed != production_count * 2)
    {
        // Wait if the buffer is empty.
        while (isBufferEmpty(shared)) 
        {
            ; // Busy-wait (do nothing).

        }
        
        // Read an item from the buffer, update read position and consumed count.
        int item = shared->data[shared->read_pos];
        shared->read_pos = (shared->read_pos + 1) % BUFFER_SIZE;
        shared->total_consumed++;
        
        // Print the consumption status.
        printf("Consumer %d consumed: %d. Total items consumed: %d\n", consumer_id, item, shared->total_consumed);
        sleep(3);
    }
}

int main() 
{   
    // Prompt user for the number of items each producer should create.
    printf("Enter the number of items each producer will create: ");
    scanf("%d", &production_count);
    
    // Allocate a shared memory segment.
    int shm_id = shmget(200, sizeof(shared_buffer_Data_Struct), 0666|IPC_CREAT);
    
    // Attach the shared memory segment to our address space.
    shared_buffer_Data_Struct* shared_memory = (shared_buffer_Data_Struct*)shmat(shm_id, NULL, 0);
    
    // Initialize the shared buffer's write and read positions, and the consumed and produced counters.
    shared_memory->write_pos = 0;
    shared_memory->read_pos = 0;
    shared_memory->total_consumed = 0;
    shared_memory->total_produced = 0;

    // Variable to hold the process ID.
    pid_t child_pid;

    // Loop to create 5 child processes.
    for (int i = 0; i < 4; i++) 
    {       
        // Create a new process.
        child_pid = fork();

        if (child_pid == 0) 
        {   
            // The first two processes will act as producers.
            if (i < 2) 
            {
                producer(shared_memory, i + 1);
                exit(0);// Exit after completing the production.
            } 
            else // The remaining processes will act as consumers.

            {
                consumer(shared_memory, i - 1);
                exit(0);// Exit after completing the consumption.
            }
        }
    }
    
    consumer(shared_memory, 3);

    // Wait for all child processes to finish.
    for (int i = 0; i < 4; i++) 
    {
        wait(NULL);
    }

    // Exit the main process.
    return 0;
}