install.packages("reshape2")
library(reshape2)

install.packages("treemapify")
library(treemapify)
install.packages("ggplot2")
install.packages("ggplot2")

library(ggplot2)
library(dplyr)

install.packages("maps")
library(maps)

# Load the dataset
cars_data <- read.csv('/Users/saifhaddad/Downloads/Cars-usa.csv')

#################### Visualization 1:

numeric_cols <- cars_data[, sapply(cars_data, is.numeric)]

correlation_matrix <- cor(numeric_cols, use="complete.obs")

melted_corr <- melt(correlation_matrix)


ggplot(data = melted_corr, aes(x = Var1, y = Var2, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1, 1), space = "Lab", 
                       name="Correlation") +
  theme_minimal() + 
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1)) +
  coord_fixed() +
  labs(title = "Correlation Heatmap",
       x = "Variables",
       y = "Variables")


#################### Visualization 2: Count of Cars by Transmission Type with Different Colors for Each Bar

ggplot(cars_data, aes(x = transmission, fill = transmission)) +
  geom_bar(color = "black") +
  ggtitle("Count of Cars by Transmission Type") +
  xlab("Transmission Type") +
  ylab("Count") +
  theme_minimal() +
  scale_fill_discrete(name = "Transmission Type")

#################### Visualization 3: Average Price by Transmission Type with Different Colors for Each Bar

ggplot(cars_data %>% group_by(transmission) %>% summarise(mean_price = mean(price)), aes(x = transmission, y = mean_price, fill = transmission)) +
  geom_bar(stat = "identity", color = "black") +
  ggtitle("Average Price by Transmission Type") +
  xlab("Transmission Type") +
  ylab("Average Price") +
  theme_minimal() +
  scale_fill_discrete(name = "Transmission Type")




#################### Visualization 4: Average Mileage by Fuel Type

ggplot(cars_data %>% group_by(fuelType) %>% summarise(mean_mileage = mean(mileage)), aes(x = fuelType, y = mean_mileage)) +
  geom_bar(stat = "identity", fill = "purple", color = "black") +
  ggtitle("Average Mileage by Fuel Type") +
  xlab("Fuel Type") +
  ylab("Average Mileage") +
  theme_minimal()

#################### Visualization 5:Price vs. Normalized Mileage Scatter Plot

# Normalize the mileage column
cars_data$normalized_mileage <- cars_data$mileage / 1e+05

ggplot(cars_data, aes(x = normalized_mileage, y = price)) +
  geom_point(color = "red", alpha = 0.6) +
  ggtitle("Price vs. Normalized Mileage") +
  xlab("Normalized Mileage (1e+05)") +
  ylab("Price") +
  theme_minimal()




#################### Visualization 6: Average Price by Fuel Type

ggplot(cars_data %>% group_by(fuelType) %>% summarise(mean_price = mean(price)), aes(x = fuelType, y = mean_price)) +
  geom_bar(stat = "identity", fill = "magenta", color = "black") +
  ggtitle("Average Price by Fuel Type") +
  xlab("Fuel Type") +
  ylab("Average Price") +
  theme_minimal()


#################### Visualization 7:

car_summary <- cars_data %>%
  group_by(fuelType) %>%
  summarise(count = n(), avg_tax = mean(tax, na.rm = TRUE)) %>%
  ungroup()
ggplot(car_summary, aes(area = count, fill = fuelType, label = fuelType)) +
  geom_treemap() +
  geom_treemap_text(fontface = "italic", colour = "white", place = "centre", grow = TRUE) +
  scale_fill_manual(values = c("Petrol" = "blue", "Diesel" = "red", "Hybrid" = "green", "Electric" = "purple","Other"="gray")) +
  labs(title = "Treemap of Car Fuel Type by Count and Average Tax") +
  theme(legend.position = "bottom")





#################### Visualization 8:

car_summary <- cars_data %>%
  group_by(Make) %>%
  summarise(count = n()) %>%
  ungroup()
ggplot(car_summary, aes(x = Make, y = count, size = count, fill = Make)) +
  geom_point(alpha = 0.7, shape = 21) +
  scale_size(range = c(3, 20), name = "Number of Cars") +
  theme_minimal() +
  labs(title = "Bubble Chart of Car Make by Count",
       x = "Car Make",
       y = "Count") +
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45, hjust = 1))


#################### Visualization 9:
car_summary <- cars_data %>%
  group_by(Make, year) %>%
  summarise(count = n()) %>%
  ungroup()
ggplot(car_summary, aes(x = Make, y = count, color = as.factor(year), size = count)) +
  geom_point(alpha = 0.6, position = position_jitter(width = 0.2, height = 0)) +
  theme_minimal() +
  labs(title = "Scatter Plot of Car Quantity by Make and Model Year",
       x = "Make",
       y = "Quantity",
       color = "Model Year") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "bottom")

#################### Visualization 10:

cars_data$year <- as.integer(as.character(cars_data$year))

yearly_mileage_data <- cars_data %>%
  group_by(year) %>%
  summarise(average_mileage_km = mean(average_mileage_km, na.rm = TRUE)) %>%
  arrange(year)  # Sort data by year

line_plot <- ggplot(yearly_mileage_data, aes(x = year, y = average_mileage_km)) +
  geom_line(color = "blue") +  
  geom_point(color = "red") +  
  labs(title = "Average Mileage Per Year (km)",
       x = "Year",
       y = "Average Mileage (km)") +
  theme_minimal()

print(line_plot)


#################### Visualization 11:

state_data <- cars_data %>%
  group_by(states) %>%
  summarise(average_price = mean(price, na.rm = TRUE)) %>%
  ungroup()  # Ensure the data is not grouped for later operations

us_map <- map_data("state")

state_data$region <- tolower(state_data$states)
map_data <- merge(us_map, state_data, by = "region", all.x = TRUE)

centroids <- aggregate(cbind(long, lat) ~ region, data = map_data, FUN = mean)

ggplot() +
  geom_polygon(data = map_data, aes(x = long, y = lat, group = group, fill = average_price), color = "white") +
  geom_text(data = centroids, aes(x = long, y = lat, label = region), color = "black", size = 3, check_overlap = TRUE, hjust = 0.5, vjust = 0.5) +
  scale_fill_gradient(low = "blue", high = "red", guide = "colorbar") +
  labs(title = "Average Car Price by State", fill = "Average Price") +
  coord_fixed(1.3) +
  theme_minimal() +
  theme(axis.text = element_blank(),
        axis.title = element_blank(),
        axis.ticks = element_blank(),
        panel.background = element_blank(),
        panel.border = element_blank(),
        panel.grid = element_blank(),
        plot.background = element_blank(),
        legend.position = "right")




################################################### Interactive ########################################################

# Interactive Chart 1: Interactive Average Price by Year
library(ggplot2)
library(plotly)
library(dplyr)
cars_data$year <- as.integer(as.character(cars_data$year))

yearly_price_data <- cars_data %>%
  group_by(year) %>%
  summarise(average_price = mean(price, na.rm = TRUE)) %>%
  arrange(year)  

p <- ggplot(yearly_price_data, aes(x = year, y = average_price)) +
  geom_line(color = "blue") +  
  geom_point(color = "red") +  
  labs(title = "Average Price Per Year ($)",
       x = "Year",
       y = "Average Price ($)") +
  theme_minimal()

interactive_plot <- ggplotly(p)

interactive_plot





# Interactive Chart 2: Average of milage by state
state_data <- cars_data %>%
  group_by(states) %>%
  summarise(average_mileage_km = mean(average_mileage_km, na.rm = TRUE)) %>%
  ungroup()

us_map <- map_data("state")

state_data$region <- tolower(state_data$states)
map_data <- merge(us_map, state_data, by = "region", all.x = TRUE)

centroids <- map_data %>%
  group_by(region) %>%
  summarise(long = mean(long), lat = mean(lat))

static_map <- ggplot() +
  geom_polygon(data = map_data, aes(x = long, y = lat, group = group, fill = average_mileage_km), color = "white") +
  geom_text(data = centroids, aes(x = long, y = lat, label = region), color = "black", size = 3, check_overlap = TRUE, hjust = 0.5, vjust = 0.5) +
  scale_fill_gradient(low = "blue", high = "red", guide = "colorbar") +
  labs(title = "Average Car Mileage by State", fill = "Average Mileage (km)") +
  coord_fixed(1.3) +
  theme_minimal() +
  theme(axis.text = element_blank(),
        axis.title = element_blank(),
        axis.ticks = element_blank(),
        panel.background = element_blank(),
        panel.border = element_blank(),
        panel.grid = element_blank(),
        plot.background = element_blank(),
        legend.position = "right")

interactive_map <- ggplotly(static_map) %>%
  layout(width = 1000, height = 600)  # Adjust these dimensions as needed

interactive_map


# Interactive Chart 3: Interactive Treemap
treemap_data <- cars_data %>%
  group_by(transmission) %>%
  summarise(count = n())

interactive_treemap_plot <- plot_ly(
  type = "treemap",
  labels = treemap_data$transmission,
  parents = NA,
  values = treemap_data$count,
  textinfo = "label",  
  marker = list(colors = colorRampPalette(c("blue", "red", "purple"))(length(treemap_data$transmission)))
) %>%
  layout(title = list(text = "Interactive Treemap by Transmission Type", x = 0.5))

interactive_treemap_plot



# Interactive Chart 4: Count of Cars by Transmission Type and Make
interactive_bar_chart <- ggplot(cars_data, aes(x = transmission, fill = Make)) +
  geom_bar(position = "dodge", color = "black") +
  ggtitle("Count of Cars by Transmission Type and Make") +
  xlab("Transmission Type") +
  ylab("Count") +
  labs(fill = "Make") +
  theme_minimal()

interactive_bar_chart_plot <- ggplotly(interactive_bar_chart)
interactive_bar_chart_plot




# Interactive Chart 5: Count of Cars by Transmission Type and Fuel Type
interactive_stacked_bar_chart <- ggplot(cars_data, aes(x = transmission, fill = fuelType)) +
  geom_bar(position = "stack", color = "black") +
  ggtitle("Count of Cars by Transmission Type and Fuel Type") +
  xlab("Transmission Type") +
  ylab("Count") +
  labs(fill = "Fuel Type") +
  theme_minimal()

interactive_stacked_bar_chart_plot <- ggplotly(interactive_stacked_bar_chart)
interactive_stacked_bar_chart_plot



################################### Dashboard ############################################



library(shiny)
library(ggplot2)
library(dplyr)
library(plotly)
library(maps)


ui <- fluidPage(
  titlePanel("Interactive Dashboard for Car Data"),
  sidebarLayout(
    sidebarPanel(
      selectInput("fuelType", "Select Fuel Type:", 
                  choices = unique(cars_data$fuelType), 
                  selected = unique(cars_data$fuelType)[1]),
      sliderInput("year_range", "Select Year Range:",
                  min = min(cars_data$year), max = max(cars_data$year),
                  value = c(min(cars_data$year), max(cars_data$year)), step = 1),
      sliderInput("price_range", "Select Price Range:",
                  min = min(cars_data$price, na.rm = TRUE), max = max(cars_data$price, na.rm = TRUE),
                  value = c(min(cars_data$price, na.rm = TRUE), max(cars_data$price, na.rm = TRUE)), step = 1000)
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Interactive Map", plotlyOutput("interactive_map")),
        tabPanel("Interactive Line Plot", plotlyOutput("interactive_line")),
        tabPanel("Interactive Bar Chart", plotlyOutput("interactive_bar")),
        tabPanel("Price vs. Normalized Mileage Scatter Plot", plotlyOutput("interactive_scatter")),
        tabPanel("Distribution of Car Prices", plotlyOutput("interactive_histogram")),
        tabPanel("Average Price by Transmission Type", plotlyOutput("interactive_avg_price_by_transmission"))
      )
    )
  )
)

server <- function(input, output) {
  filtered_data <- reactive({
    cars_data %>%
      filter(fuelType == input$fuelType,
             year >= input$year_range[1], year <= input$year_range[2],
             price >= input$price_range[1], price <= input$price_range[2])
  })
  
  output$interactive_map <- renderPlotly({
    map_data <- filtered_data() %>%
      group_by(states) %>%
      summarise(average_price = mean(price, na.rm = TRUE)) %>%
      ungroup()
    
    us_map <- map_data("state")
    map_data$region <- tolower(map_data$states)
    merged_data <- merge(us_map, map_data, by = "region", all.x = TRUE)
    
    centroids <- merged_data %>%
      group_by(region) %>%
      summarise(long = mean(long), lat = mean(lat))
    
    static_map <- ggplot() +
      geom_polygon(data = merged_data, aes(x = long, y = lat, group = group, fill = average_price), color = "white") +
      geom_text(data = centroids, aes(x = long, y = lat, label = region), color = "black", size = 3, check_overlap = TRUE, hjust = 0.5, vjust = 0.5) +
      scale_fill_gradient(low = "blue", high = "red", guide = "colorbar") +
      labs(title = "Average Price by State", fill = "Average Price") +
      coord_fixed(1.3) +
      theme_minimal() +
      theme(axis.text = element_blank(),
            axis.title = element_blank(),
            axis.ticks = element_blank(),
            panel.background = element_blank(),
            panel.border = element_blank(),
            panel.grid = element_blank(),
            plot.background = element_blank(),
            legend.position = "right")
    
    ggplotly(static_map)
  })
  
  output$interactive_line <- renderPlotly({
    line_data <- filtered_data() %>%
      group_by(year) %>%
      summarise(average_price = mean(price, na.rm = TRUE)) %>%
      ungroup()
    
    line_plot <- ggplot(line_data, aes(x = year, y = average_price)) +
      geom_line(color = "blue", size = 1.5) +
      geom_point(color = "red", size = 3) +
      labs(title = "Average Price by Year",
           x = "Year",
           y = "Average Price ($)") +
      theme_minimal()
    
    ggplotly(line_plot)
  })
  
  output$interactive_bar <- renderPlotly({
    bar_data <- filtered_data() %>%
      group_by(transmission) %>%
      summarise(count = n())
    
    bar_plot <- ggplot(bar_data, aes(x = transmission, y = count, fill = transmission)) +
      geom_bar(stat = "identity") +
      labs(title = "Count of Cars by Transmission Type",
           x = "Transmission Type",
           y = "Count") +
      theme_minimal()
    
    ggplotly(bar_plot)
  })
  
  output$interactive_scatter <- renderPlotly({
    scatter_data <- filtered_data()
    scatter_data$normalized_mileage <- scatter_data$mileage / 1e+05
    
    scatter_plot <- ggplot(scatter_data, aes(x = normalized_mileage, y = price)) +
      geom_point(color = "red", alpha = 0.6) +
      labs(title = "Price vs. Normalized Mileage",
           x = "Normalized Mileage (1e+05)",
           y = "Price") +
      theme_minimal()
    
    ggplotly(scatter_plot)
  })
  
  output$interactive_histogram <- renderPlotly({
    histogram_plot <- ggplot(filtered_data(), aes(x = price)) +
      geom_histogram(binwidth = 4000, fill = "blue", color = "black") +
      labs(title = "Distribution of Car Prices",
           x = "Price",
           y = "Frequency") +
      theme_minimal() +
      scale_x_continuous(limits = c(0, 50000), breaks = seq(0, 50000, by = 5000))
    
    ggplotly(histogram_plot)
  })
  
  output$interactive_avg_price_by_transmission <- renderPlotly({
    avg_price_by_transmission <- filtered_data() %>%
      group_by(transmission) %>%
      summarise(mean_price = mean(price, na.rm = TRUE))
    
    avg_price_plot <- ggplot(avg_price_by_transmission, aes(x = transmission, y = mean_price, fill = transmission)) +
      geom_bar(stat = "identity", color = "black") +
      labs(title = "Average Price by Transmission Type",
           x = "Transmission Type",
           y = "Average Price") +
      theme_minimal()
    
    ggplotly(avg_price_plot)
  })
}

shinyApp(ui = ui, server = server)

