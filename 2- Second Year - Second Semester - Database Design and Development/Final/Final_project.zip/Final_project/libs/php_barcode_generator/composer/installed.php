<?php return array(
    'root' => array(
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => NULL,
        'name' => '__root__',
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => NULL,
            'dev_requirement' => false,
        ),
        'picqer/php-barcode-generator' => array(
            'pretty_version' => 'v2.2.2',
            'version' => '2.2.2.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../picqer/php-barcode-generator',
            'aliases' => array(),
            'reference' => '877fcb0e9279ac40646361a7d7a7c6d0e1639836',
            'dev_requirement' => false,
        ),
    ),
);
