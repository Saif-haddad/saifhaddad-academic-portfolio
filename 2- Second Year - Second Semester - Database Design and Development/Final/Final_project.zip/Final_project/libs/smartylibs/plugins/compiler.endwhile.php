<?php
function smarty_compiler_endwhile($tag_arg, &$smarty)
{
    return '}';
}
?>
