<?php

function smarty_function_n($params, &$smarty)
{
    return ' ';
}

?>