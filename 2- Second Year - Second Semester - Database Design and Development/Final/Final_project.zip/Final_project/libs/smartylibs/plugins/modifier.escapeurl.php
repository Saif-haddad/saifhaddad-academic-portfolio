<?php

function smarty_modifier_escapeurl($string)
{
	return htmlspecialchars($string);
}

?>
