<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    <?php echo 'google.charts.load(\'49\', {packages: [\'corechart\', \'geochart\', \'timeline\', \'gantt\', \'treemap\']});'; ?>

</script>